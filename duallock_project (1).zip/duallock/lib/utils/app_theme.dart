// lib/utils/app_theme.dart
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  // Colors
  static const Color primaryBlack = Color(0xFF0A0A0F);
  static const Color secondaryBlack = Color(0xFF12121A);
  static const Color cardBlack = Color(0xFF1A1A24);
  static const Color primaryBlue = Color(0xFF2979FF);
  static const Color accentBlue = Color(0xFF448AFF);
  static const Color lightBlue = Color(0xFF82B1FF);
  static const Color pureWhite = Color(0xFFFFFFFF);
  static const Color softWhite = Color(0xFFE8EAF6);
  static const Color greyText = Color(0xFF9E9E9E);
  static const Color dangerRed = Color(0xFFFF1744);
  static const Color successGreen = Color(0xFF00E676);
  static const Color dividerColor = Color(0xFF1E1E2E);

  static ThemeData darkTheme = ThemeData(
    brightness: Brightness.dark,
    scaffoldBackgroundColor: primaryBlack,
    primaryColor: primaryBlue,
    colorScheme: const ColorScheme.dark(
      primary: primaryBlue,
      secondary: accentBlue,
      surface: cardBlack,
      background: primaryBlack,
      error: dangerRed,
    ),
    textTheme: GoogleFonts.cairoTextTheme(
      const TextTheme(
        displayLarge: TextStyle(color: pureWhite, fontWeight: FontWeight.bold),
        displayMedium: TextStyle(color: pureWhite, fontWeight: FontWeight.bold),
        headlineLarge: TextStyle(color: pureWhite, fontWeight: FontWeight.bold, fontSize: 28),
        headlineMedium: TextStyle(color: pureWhite, fontWeight: FontWeight.w600, fontSize: 22),
        headlineSmall: TextStyle(color: pureWhite, fontWeight: FontWeight.w600, fontSize: 18),
        bodyLarge: TextStyle(color: softWhite, fontSize: 16),
        bodyMedium: TextStyle(color: softWhite, fontSize: 14),
        bodySmall: TextStyle(color: greyText, fontSize: 12),
        labelLarge: TextStyle(color: pureWhite, fontWeight: FontWeight.w600),
      ),
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: primaryBlack,
      elevation: 0,
      centerTitle: true,
      titleTextStyle: GoogleFonts.cairo(
        color: pureWhite,
        fontSize: 20,
        fontWeight: FontWeight.bold,
      ),
      iconTheme: const IconThemeData(color: pureWhite),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: primaryBlue,
        foregroundColor: pureWhite,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
        textStyle: GoogleFonts.cairo(fontSize: 16, fontWeight: FontWeight.bold),
      ),
    ),
    cardTheme: CardTheme(
      color: cardBlack,
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
    ),
    dividerTheme: const DividerThemeData(color: dividerColor, thickness: 1),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: cardBlack,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide.none,
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: primaryBlue, width: 1.5),
      ),
      hintStyle: const TextStyle(color: greyText),
      labelStyle: const TextStyle(color: greyText),
    ),
  );
}

class AppConstants {
  static const String appName = 'DualLock';
  static const String appVersion = '1.0.0';
  static const String realPatternKey = 'real_pattern_hash';
  static const String decoyPatternKey = 'decoy_pattern_hash';
  static const String selectedAppsKey = 'selected_decoy_apps';
  static const String selectedPhotosKey = 'selected_decoy_photos';
  static const String isSetupCompleteKey = 'is_setup_complete';
  static const String isLockEnabledKey = 'is_lock_enabled';
  static const int splashDuration = 3;
}
