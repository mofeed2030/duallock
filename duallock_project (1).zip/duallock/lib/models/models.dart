// lib/models/app_model.dart
class AppModel {
  final String packageName;
  final String appName;
  final String? icon; // base64 encoded icon
  bool isSelected;
  bool hasContentControl; // e.g., Gallery

  AppModel({
    required this.packageName,
    required this.appName,
    this.icon,
    this.isSelected = false,
    this.hasContentControl = false,
  });

  Map<String, dynamic> toMap() => {
    'packageName': packageName,
    'appName': appName,
    'icon': icon,
    'isSelected': isSelected ? 1 : 0,
    'hasContentControl': hasContentControl ? 1 : 0,
  };

  factory AppModel.fromMap(Map<String, dynamic> map) => AppModel(
    packageName: map['packageName'],
    appName: map['appName'],
    icon: map['icon'],
    isSelected: map['isSelected'] == 1,
    hasContentControl: map['hasContentControl'] == 1,
  );

  // Apps that support content control
  static const List<String> contentControlApps = [
    'com.google.android.apps.photos',
    'com.miui.gallery',
    'com.sec.android.gallery3d',
    'com.android.gallery3d',
  ];

  static bool supportsContentControl(String packageName) {
    return contentControlApps.any((pkg) => packageName.contains('gallery') ||
        packageName.contains('photo'));
  }
}

// lib/models/photo_album_model.dart
class PhotoAlbumModel {
  final String id;
  final String name;
  final String? coverPath;
  final int count;
  bool isSelected;

  PhotoAlbumModel({
    required this.id,
    required this.name,
    this.coverPath,
    required this.count,
    this.isSelected = false,
  });
}

// lib/models/user_settings_model.dart
class UserSettings {
  bool isSetupComplete;
  bool isLockEnabled;
  bool isDecoyEnabled;
  bool showPanicButton;
  bool hideFromLauncher;
  String decoyWallpaper;
  String decoyTheme;
  String userEmail;
  String userId;

  UserSettings({
    this.isSetupComplete = false,
    this.isLockEnabled = false,
    this.isDecoyEnabled = false,
    this.showPanicButton = true,
    this.hideFromLauncher = false,
    this.decoyWallpaper = 'default',
    this.decoyTheme = 'dark',
    this.userEmail = '',
    this.userId = '',
  });

  Map<String, dynamic> toMap() => {
    'isSetupComplete': isSetupComplete ? 1 : 0,
    'isLockEnabled': isLockEnabled ? 1 : 0,
    'isDecoyEnabled': isDecoyEnabled ? 1 : 0,
    'showPanicButton': showPanicButton ? 1 : 0,
    'hideFromLauncher': hideFromLauncher ? 1 : 0,
    'decoyWallpaper': decoyWallpaper,
    'decoyTheme': decoyTheme,
    'userEmail': userEmail,
    'userId': userId,
  };

  factory UserSettings.fromMap(Map<String, dynamic> map) => UserSettings(
    isSetupComplete: map['isSetupComplete'] == 1,
    isLockEnabled: map['isLockEnabled'] == 1,
    isDecoyEnabled: map['isDecoyEnabled'] == 1,
    showPanicButton: map['showPanicButton'] == 1,
    hideFromLauncher: map['hideFromLauncher'] == 1,
    decoyWallpaper: map['decoyWallpaper'] ?? 'default',
    decoyTheme: map['decoyTheme'] ?? 'dark',
    userEmail: map['userEmail'] ?? '',
    userId: map['userId'] ?? '',
  );
}
