// lib/screens/settings/settings_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../utils/app_theme.dart';
import '../../services/app_state_provider.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<AppStateProvider>(
      builder: (context, provider, _) {
        final settings = provider.settings;
        return Scaffold(
          backgroundColor: AppTheme.primaryBlack,
          appBar: AppBar(title: const Text('الإعدادات')),
          body: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              _SectionTitle(title: 'الأمان'),
              _SettingsTile(
                icon: Icons.warning_rounded,
                iconColor: AppTheme.dangerRed,
                title: 'زر الطوارئ',
                subtitle: 'إظهار زر الطوارئ في شاشة القفل',
                trailing: Switch(
                  value: settings.showPanicButton,
                  onChanged: (val) {
                    settings.showPanicButton = val;
                    provider.updateSettings(settings);
                  },
                  activeColor: AppTheme.primaryBlue,
                ),
              ),
              _SettingsTile(
                icon: Icons.visibility_off_rounded,
                iconColor: const Color(0xFF7C4DFF),
                title: 'إخفاء التطبيق',
                subtitle: 'إخفاء التطبيق من قائمة التطبيقات',
                trailing: Switch(
                  value: settings.hideFromLauncher,
                  onChanged: (val) {
                    settings.hideFromLauncher = val;
                    provider.updateSettings(settings);
                  },
                  activeColor: AppTheme.primaryBlue,
                ),
              ),
              const SizedBox(height: 24),
              _SectionTitle(title: 'المظهر'),
              _SettingsTile(
                icon: Icons.palette_rounded,
                iconColor: const Color(0xFF00BCD4),
                title: 'ثيم الواجهة الوهمية',
                subtitle: settings.decoyTheme == 'dark' ? 'داكن' : 'فاتح',
                onTap: () => _showThemeDialog(context, provider),
              ),
              _SettingsTile(
                icon: Icons.wallpaper_rounded,
                iconColor: AppTheme.primaryBlue,
                title: 'خلفية الواجهة الوهمية',
                subtitle: 'اختر خلفية مختلفة',
                onTap: () {},
              ),
              const SizedBox(height: 24),
              _SectionTitle(title: 'البيانات'),
              _SettingsTile(
                icon: Icons.delete_forever_rounded,
                iconColor: AppTheme.dangerRed,
                title: 'إعادة تعيين التطبيق',
                subtitle: 'حذف جميع الأنماط والإعدادات',
                onTap: () => _showResetDialog(context, provider),
              ),
              const SizedBox(height: 40),
              // App version
              Center(
                child: Text(
                  'DualLock v1.0.0',
                  style: const TextStyle(color: AppTheme.greyText, fontSize: 12),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void _showThemeDialog(BuildContext context, AppStateProvider provider) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppTheme.cardBlack,
        title: const Text('ثيم الواجهة', style: TextStyle(color: AppTheme.pureWhite)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              title: const Text('داكن', style: TextStyle(color: AppTheme.pureWhite)),
              leading: const Icon(Icons.dark_mode_rounded, color: AppTheme.primaryBlue),
              onTap: () {
                provider.settings.decoyTheme = 'dark';
                provider.updateSettings(provider.settings);
                Navigator.pop(context);
              },
            ),
            ListTile(
              title: const Text('فاتح', style: TextStyle(color: AppTheme.pureWhite)),
              leading: const Icon(Icons.light_mode_rounded, color: AppTheme.primaryBlue),
              onTap: () {
                provider.settings.decoyTheme = 'light';
                provider.updateSettings(provider.settings);
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showResetDialog(BuildContext context, AppStateProvider provider) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppTheme.cardBlack,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('تحذير',
            style: TextStyle(color: AppTheme.dangerRed, fontWeight: FontWeight.bold)),
        content: const Text(
          'سيتم حذف جميع الأنماط والإعدادات. هذا الإجراء لا يمكن التراجع عنه.',
          style: TextStyle(color: AppTheme.greyText),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء', style: TextStyle(color: AppTheme.greyText)),
          ),
          ElevatedButton(
            onPressed: () async {
              // Reset logic
              Navigator.pop(context);
            },
            style: ElevatedButton.styleFrom(backgroundColor: AppTheme.dangerRed),
            child: const Text('إعادة التعيين'),
          ),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  const _SectionTitle({required this.title});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: Text(title,
        style: const TextStyle(
            color: AppTheme.primaryBlue,
            fontSize: 13,
            fontWeight: FontWeight.bold,
            letterSpacing: 0.5)),
  );
}

class _SettingsTile extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String title;
  final String subtitle;
  final Widget? trailing;
  final VoidCallback? onTap;

  const _SettingsTile({
    required this.icon,
    required this.iconColor,
    required this.title,
    required this.subtitle,
    this.trailing,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: AppTheme.cardBlack,
        borderRadius: BorderRadius.circular(16),
      ),
      child: ListTile(
        onTap: onTap,
        leading: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: iconColor.withOpacity(0.15),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, color: iconColor, size: 22),
        ),
        title: Text(title,
            style: const TextStyle(color: AppTheme.pureWhite, fontSize: 14)),
        subtitle: Text(subtitle,
            style: const TextStyle(color: AppTheme.greyText, fontSize: 12)),
        trailing: trailing ??
            const Icon(Icons.arrow_forward_ios_rounded,
                color: AppTheme.greyText, size: 14),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      ),
    );
  }
}
