// lib/screens/settings/info_screens.dart
import 'package:flutter/material.dart';
import '../../utils/app_theme.dart';

// ─── About Screen ─────────────────────────────────────────────────────────────
class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return _InfoScaffold(
      title: 'حول التطبيق',
      child: Column(
        children: [
          // Logo
          Container(
            width: 100,
            height: 100,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                  colors: [AppTheme.primaryBlue, AppTheme.accentBlue]),
              borderRadius: BorderRadius.circular(28),
              boxShadow: [BoxShadow(
                  color: AppTheme.primaryBlue.withOpacity(0.4),
                  blurRadius: 30)],
            ),
            child: const Icon(Icons.lock_rounded, color: Colors.white, size: 52),
          ),
          const SizedBox(height: 20),
          const Text('DualLock',
              style: TextStyle(color: AppTheme.pureWhite, fontSize: 28,
                  fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('الإصدار 1.0.0',
              style: TextStyle(color: AppTheme.greyText, fontSize: 14)),
          const SizedBox(height: 32),
          _InfoSection(
            title: 'ما هو DualLock؟',
            content: 'DualLock هو تطبيق قفل شاشة ذكي يوفر حماية مزدوجة لهاتفك. '
                'يتيح لك إنشاء نمطين مختلفين للقفل: نمط حقيقي يفتح الهاتف بالكامل، '
                'ونمط وهمي يعرض واجهة بديلة مع محتوى محدود تختاره أنت.',
          ),
          _InfoSection(
            title: 'التقنيات المستخدمة',
            content: 'مبني بتقنية Flutter لدعم Android 8 وما فوق.\n'
                'تشفير SHA-256 لحماية الأنماط.\n'
                'قاعدة بيانات SQLite للتخزين الآمن.',
          ),
          _InfoSection(
            title: 'التواصل',
            content: 'contact@duallock.app\nwww.duallock.app',
          ),
        ],
      ),
    );
  }
}

// ─── Who We Are ───────────────────────────────────────────────────────────────
class WhoWeAreScreen extends StatelessWidget {
  const WhoWeAreScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return _InfoScaffold(
      title: 'من نحن',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: const [
          _InfoSection(
            title: 'فريق DualLock',
            content: 'نحن فريق متخصص في تطوير تطبيقات الأمان والخصوصية للهواتف الذكية. '
                'هدفنا الأساسي هو توفير أدوات تقنية تحمي خصوصية المستخدمين في العالم العربي وعالمياً.',
          ),
          _InfoSection(
            title: 'رؤيتنا',
            content: 'نؤمن بأن الخصوصية الرقمية حق أساسي لكل شخص. '
                'لذلك نسعى إلى تطوير حلول ذكية وسهلة الاستخدام تجمع بين الأمان والبساطة.',
          ),
          _InfoSection(
            title: 'قيمنا',
            content: '• الأمان أولاً في كل قرار تقني\n'
                '• الخصوصية حق غير قابل للتفاوض\n'
                '• البساطة في الاستخدام مع القوة في الأداء\n'
                '• الشفافية مع مستخدمينا',
          ),
        ],
      ),
    );
  }
}

// ─── How It Works ─────────────────────────────────────────────────────────────
class HowItWorksScreen extends StatelessWidget {
  const HowItWorksScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return _InfoScaffold(
      title: 'كيف يعمل التطبيق',
      child: Column(
        children: [
          _StepCard(
            step: '١',
            title: 'إنشاء النمط الحقيقي',
            description: 'أنشئ رمز PIN من 6 أرقام سيستخدم لفتح هاتفك الحقيقي بجميع تطبيقاته وبياناته.',
            color: AppTheme.primaryBlue,
            icon: Icons.lock_rounded,
          ),
          _StepCard(
            step: '٢',
            title: 'إنشاء النمط الوهمي',
            description: 'أنشئ رمز PIN مختلف سيستخدم لفتح الواجهة الوهمية المحدودة.',
            color: const Color(0xFF7C4DFF),
            icon: Icons.layers_rounded,
          ),
          _StepCard(
            step: '٣',
            title: 'اختيار المحتوى الوهمي',
            description: 'حدد التطبيقات والصور التي ستظهر فقط في الواجهة الوهمية.',
            color: const Color(0xFF00BCD4),
            icon: Icons.checklist_rounded,
          ),
          _StepCard(
            step: '٤',
            title: 'تفعيل القفل',
            description: 'فعّل القفل المزدوج. الآن هاتفك محمي بطريقتين!',
            color: AppTheme.successGreen,
            icon: Icons.security_rounded,
          ),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppTheme.dangerRed.withOpacity(0.1),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppTheme.dangerRed.withOpacity(0.3)),
            ),
            child: const Row(
              children: [
                Icon(Icons.tips_and_updates_rounded, color: AppTheme.dangerRed),
                SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'نصيحة: استخدم رموز مختلفة تماماً للنمطين لضمان أقصى حماية.',
                    style: TextStyle(color: AppTheme.softWhite, fontSize: 13, height: 1.5),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Privacy Policy ───────────────────────────────────────────────────────────
class PrivacyPolicyScreen extends StatelessWidget {
  const PrivacyPolicyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return _InfoScaffold(
      title: 'سياسة الخصوصية',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: const [
          _InfoSection(title: 'جمع البيانات',
              content: 'لا نجمع أي بيانات شخصية دون إذنك الصريح. جميع الأنماط والإعدادات تُخزَّن محلياً على جهازك فقط ومشفرة.'),
          _InfoSection(title: 'تخزين البيانات',
              content: 'يتم تخزين جميع بياناتك (الأنماط، التطبيقات المحددة، الإعدادات) محلياً على جهازك باستخدام تشفير قوي. لا يتم إرسال أي بيانات إلى خوادمنا.'),
          _InfoSection(title: 'الأذونات',
              content: 'يطلب التطبيق أذونات ضرورية فقط لعمله:\n• الرسم فوق التطبيقات الأخرى: لعرض شاشة القفل\n• إحصاءات الاستخدام: لمراقبة التطبيقات المفتوحة\n• الوصول إلى الصور: لعرض الألبومات المحددة'),
          _InfoSection(title: 'مشاركة البيانات',
              content: 'لا نشارك أي بيانات مع أطراف ثالثة تحت أي ظرف كان.'),
          _InfoSection(title: 'التواصل',
              content: 'لأي استفسار: privacy@duallock.app'),
        ],
      ),
    );
  }
}

// ─── Terms of Service ─────────────────────────────────────────────────────────
class TermsScreen extends StatelessWidget {
  const TermsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return _InfoScaffold(
      title: 'شروط الاستخدام',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: const [
          _InfoSection(title: 'القبول بالشروط',
              content: 'باستخدام تطبيق DualLock، فإنك توافق على الالتزام بهذه الشروط والأحكام.'),
          _InfoSection(title: 'الاستخدام المقبول',
              content: 'يُسمح باستخدام التطبيق لأغراض قانونية فقط لحماية خصوصيتك الشخصية. يُحظر استخدام التطبيق لأي غرض غير قانوني.'),
          _InfoSection(title: 'إخلاء المسؤولية',
              content: 'التطبيق يُقدَّم "كما هو". لا نتحمل المسؤولية عن أي فقدان للبيانات أو أضرار ناتجة عن الاستخدام.'),
          _InfoSection(title: 'التعديلات',
              content: 'نحتفظ بحق تعديل هذه الشروط في أي وقت. سيتم إخطارك بأي تغييرات جوهرية.'),
          _InfoSection(title: 'إنهاء الخدمة',
              content: 'يمكنك إنهاء استخدام التطبيق في أي وقت بحذفه من جهازك.'),
        ],
      ),
    );
  }
}

// ─── Reusable Components ──────────────────────────────────────────────────────
class _InfoScaffold extends StatelessWidget {
  final String title;
  final Widget child;

  const _InfoScaffold({required this.title, required this.child});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.primaryBlack,
      appBar: AppBar(title: Text(title)),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: child,
      ),
    );
  }
}

class _InfoSection extends StatelessWidget {
  final String title;
  final String content;

  const _InfoSection({required this.title, required this.content});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title,
              style: const TextStyle(
                  color: AppTheme.primaryBlue,
                  fontSize: 15,
                  fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Text(content,
              style: const TextStyle(
                  color: AppTheme.softWhite, fontSize: 14, height: 1.7)),
        ],
      ),
    );
  }
}

class _StepCard extends StatelessWidget {
  final String step;
  final String title;
  final String description;
  final Color color;
  final IconData icon;

  const _StepCard({
    required this.step,
    required this.title,
    required this.description,
    required this.color,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.cardBlack,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: color.withOpacity(0.25)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: color.withOpacity(0.15),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Center(
              child: Text(step,
                  style: TextStyle(
                      color: color,
                      fontSize: 18,
                      fontWeight: FontWeight.bold)),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: const TextStyle(
                        color: AppTheme.pureWhite,
                        fontWeight: FontWeight.bold,
                        fontSize: 15)),
                const SizedBox(height: 4),
                Text(description,
                    style: const TextStyle(
                        color: AppTheme.greyText, fontSize: 13, height: 1.5)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
