// lib/screens/onboarding/permissions_screen.dart
import 'package:flutter/material.dart';
import '../../utils/app_theme.dart';
import '../../services/system_service.dart';
import '../home/home_screen.dart';

class PermissionsScreen extends StatefulWidget {
  const PermissionsScreen({super.key});

  @override
  State<PermissionsScreen> createState() => _PermissionsScreenState();
}

class _PermissionsScreenState extends State<PermissionsScreen> {
  final SystemService _system = SystemService();
  PermissionsStatus? _status;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _checkPermissions();
  }

  Future<void> _checkPermissions() async {
    setState(() => _isLoading = true);
    final status = await _system.checkAllPermissions();
    setState(() {
      _status = status;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.primaryBlack,
      appBar: AppBar(title: const Text('الأذونات المطلوبة')),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(20),
              children: [
                // Header
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: AppTheme.primaryBlue.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: AppTheme.primaryBlue.withOpacity(0.3)),
                  ),
                  child: Column(
                    children: [
                      const Icon(Icons.admin_panel_settings_rounded,
                          color: AppTheme.primaryBlue, size: 40),
                      const SizedBox(height: 12),
                      const Text(
                        'الأذونات المطلوبة',
                        style: TextStyle(
                            color: AppTheme.pureWhite,
                            fontSize: 18,
                            fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'يحتاج التطبيق هذه الأذونات لعمل القفل المزدوج بشكل صحيح',
                        style: const TextStyle(color: AppTheme.greyText, fontSize: 13),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),

                // Permission tiles
                _PermissionTile(
                  icon: Icons.layers_rounded,
                  title: 'الرسم فوق التطبيقات',
                  subtitle: 'لعرض شاشة القفل فوق كل التطبيقات',
                  isGranted: _status?.drawOverApps ?? false,
                  onRequest: () async {
                    await _system.requestDrawOverApps();
                    _checkPermissions();
                  },
                ),
                _PermissionTile(
                  icon: Icons.bar_chart_rounded,
                  title: 'إحصاءات استخدام التطبيقات',
                  subtitle: 'لمراقبة التطبيقات المفتوحة وتطبيق القفل',
                  isGranted: _status?.usageStats ?? false,
                  onRequest: () async {
                    await _system.requestUsageStats();
                    _checkPermissions();
                  },
                ),
                _PermissionTile(
                  icon: Icons.admin_panel_settings_rounded,
                  title: 'صلاحيات المدير',
                  subtitle: 'لمنع حذف التطبيق وقفل الشاشة',
                  isGranted: _status?.deviceAdmin ?? false,
                  onRequest: () async {
                    await _system.requestDeviceAdmin();
                    _checkPermissions();
                  },
                ),

                const SizedBox(height: 32),

                // Progress indicator
                if (_status != null) ...[
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        '${_status!.grantedCount}/3 أذونات ممنوحة',
                        style: TextStyle(
                          color: _status!.allGranted
                              ? AppTheme.successGreen
                              : AppTheme.greyText,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                ],

                // Continue button
                ElevatedButton(
                  onPressed: _status?.allGranted == true
                      ? () => Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(builder: (_) => const HomeScreen()))
                      : null,
                  style: ElevatedButton.styleFrom(
                    minimumSize: const Size.fromHeight(52),
                    disabledBackgroundColor: AppTheme.cardBlack,
                  ),
                  child: Text(
                    _status?.allGranted == true
                        ? 'متابعة'
                        : 'يرجى منح جميع الأذونات',
                  ),
                ),
                const SizedBox(height: 12),
                TextButton(
                  onPressed: () => Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(builder: (_) => const HomeScreen())),
                  child: const Text(
                    'تخطي (بعض الميزات لن تعمل)',
                    style: TextStyle(color: AppTheme.greyText, fontSize: 13),
                  ),
                ),
              ],
            ),
    );
  }
}

class _PermissionTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final bool isGranted;
  final VoidCallback onRequest;

  const _PermissionTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.isGranted,
    required this.onRequest,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.cardBlack,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: isGranted
              ? AppTheme.successGreen.withOpacity(0.4)
              : AppTheme.dividerColor,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              color: (isGranted ? AppTheme.successGreen : AppTheme.greyText)
                  .withOpacity(0.15),
              borderRadius: BorderRadius.circular(13),
            ),
            child: Icon(icon,
                color: isGranted ? AppTheme.successGreen : AppTheme.greyText,
                size: 24),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: const TextStyle(
                        color: AppTheme.pureWhite,
                        fontWeight: FontWeight.w600,
                        fontSize: 14)),
                const SizedBox(height: 3),
                Text(subtitle,
                    style: const TextStyle(
                        color: AppTheme.greyText, fontSize: 12)),
              ],
            ),
          ),
          const SizedBox(width: 8),
          isGranted
              ? const Icon(Icons.check_circle_rounded,
                  color: AppTheme.successGreen, size: 28)
              : GestureDetector(
                  onTap: onRequest,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 8),
                    decoration: BoxDecoration(
                      color: AppTheme.primaryBlue.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                          color: AppTheme.primaryBlue.withOpacity(0.4)),
                    ),
                    child: const Text('منح',
                        style: TextStyle(
                            color: AppTheme.primaryBlue,
                            fontSize: 12,
                            fontWeight: FontWeight.bold)),
                  ),
                ),
        ],
      ),
    );
  }
}
