// lib/screens/onboarding/onboarding_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../utils/app_theme.dart';
import '../../services/app_state_provider.dart';
import '../home/home_screen.dart';
import '../../widgets/gradient_button.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _pageController = PageController();
  int _currentPage = 0;

  final List<_OnboardingData> _pages = [
    _OnboardingData(
      icon: Icons.shield_rounded,
      color: AppTheme.primaryBlue,
      title: 'مرحباً بك في DualLock',
      subtitle: 'حماية خصوصيتك بذكاء',
      description: 'تطبيق قفل شاشة ذكي يتيح لك فتح هاتفك بطريقتين مختلفتين.\nالأولى حقيقية والأخرى وهمية.',
    ),
    _OnboardingData(
      icon: Icons.layers_rounded,
      color: const Color(0xFF7C4DFF),
      title: 'نمطان للقفل',
      subtitle: 'سرية تامة',
      description: 'النمط الحقيقي يفتح هاتفك الأصلي.\nالنمط الوهمي يعرض واجهة بديلة بمحتوى محدود تختاره أنت.',
    ),
    _OnboardingData(
      icon: Icons.privacy_tip_rounded,
      color: const Color(0xFF00BCD4),
      title: 'تحكم كامل',
      subtitle: 'اختر ما تُظهره',
      description: 'حدد التطبيقات والصور التي تظهر في الواجهة الوهمية.\nكل ما لم تحدده يبقى مخفياً تماماً.',
    ),
    _OnboardingData(
      icon: Icons.security_rounded,
      color: AppTheme.successGreen,
      title: 'أمان متقدم',
      subtitle: 'تشفير قوي',
      description: 'تُشفَّر أنماط القفل بتقنية SHA-256.\nحماية كاملة من تجاوز القفل أو الحذف القسري.',
    ),
  ];

  void _nextPage() {
    if (_currentPage < _pages.length - 1) {
      _pageController.nextPage(
        duration: const Duration(milliseconds: 400),
        curve: Curves.easeInOut,
      );
    } else {
      _startSetup();
    }
  }

  void _startSetup() async {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const HomeScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.primaryBlack,
      body: SafeArea(
        child: Column(
          children: [
            // Skip button
            Align(
              alignment: Alignment.topRight,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: TextButton(
                  onPressed: _startSetup,
                  child: const Text('تخطي', style: TextStyle(color: AppTheme.greyText)),
                ),
              ),
            ),
            // Pages
            Expanded(
              child: PageView.builder(
                controller: _pageController,
                onPageChanged: (i) => setState(() => _currentPage = i),
                itemCount: _pages.length,
                itemBuilder: (_, i) => _OnboardingPage(data: _pages[i]),
              ),
            ),
            // Indicators
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(
                _pages.length,
                (i) => AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  width: _currentPage == i ? 24 : 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: _currentPage == i
                        ? AppTheme.primaryBlue
                        : AppTheme.greyText.withOpacity(0.4),
                    borderRadius: BorderRadius.circular(4),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 32),
            // Next button
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 32),
              child: GradientButton(
                onPressed: _nextPage,
                text: _currentPage == _pages.length - 1 ? 'ابدأ الآن' : 'التالي',
                icon: _currentPage == _pages.length - 1
                    ? Icons.rocket_launch_rounded
                    : Icons.arrow_forward_rounded,
              ),
            ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }
}

class _OnboardingPage extends StatelessWidget {
  final _OnboardingData data;
  const _OnboardingPage({required this.data});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 32),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              color: data.color.withOpacity(0.15),
              shape: BoxShape.circle,
              border: Border.all(color: data.color.withOpacity(0.3), width: 2),
            ),
            child: Icon(data.icon, size: 60, color: data.color),
          ),
          const SizedBox(height: 40),
          Text(
            data.title,
            style: const TextStyle(
              color: AppTheme.pureWhite,
              fontSize: 26,
              fontWeight: FontWeight.bold,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 8),
          Text(
            data.subtitle,
            style: TextStyle(color: data.color, fontSize: 16, fontWeight: FontWeight.w600),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 20),
          Text(
            data.description,
            style: const TextStyle(color: AppTheme.greyText, fontSize: 15, height: 1.8),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}

class _OnboardingData {
  final IconData icon;
  final Color color;
  final String title;
  final String subtitle;
  final String description;

  _OnboardingData({
    required this.icon,
    required this.color,
    required this.title,
    required this.subtitle,
    required this.description,
  });
}
