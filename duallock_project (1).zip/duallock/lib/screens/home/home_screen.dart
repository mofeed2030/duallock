// lib/screens/home/home_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../utils/app_theme.dart';
import '../../services/app_state_provider.dart';
import '../../widgets/common_widgets.dart';
import '../lockscreen/setup_pattern_screen.dart';
import '../lockscreen/lock_screen.dart';
import '../decoy/decoy_setup_screen.dart';
import '../settings/settings_screen.dart';
import '../settings/info_screens.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<AppStateProvider>(
      builder: (context, provider, _) {
        return Scaffold(
          backgroundColor: AppTheme.primaryBlack,
          body: SafeArea(
            child: CustomScrollView(
              slivers: [
                // Header
                SliverToBoxAdapter(
                  child: _buildHeader(context, provider),
                ),
                // Status card
                SliverToBoxAdapter(
                  child: _buildStatusCard(context, provider),
                ),
                // Main options
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: _buildMainOptions(context, provider),
                  ),
                ),
                // Quick actions
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: _buildQuickActions(context),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildHeader(BuildContext context, AppStateProvider provider) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 10),
      child: Row(
        children: [
          // Logo
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [AppTheme.primaryBlue, AppTheme.accentBlue],
              ),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(Icons.lock_rounded, color: Colors.white, size: 24),
          ),
          const SizedBox(width: 12),
          const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('DualLock', style: TextStyle(
                color: AppTheme.pureWhite,
                fontSize: 20,
                fontWeight: FontWeight.bold,
              )),
              Text('حماية ذكية مزدوجة', style: TextStyle(
                color: AppTheme.greyText,
                fontSize: 12,
              )),
            ],
          ),
          const Spacer(),
          // Settings button
          IconButton(
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const SettingsScreen())),
            icon: const Icon(Icons.settings_rounded, color: AppTheme.greyText),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusCard(BuildContext context, AppStateProvider provider) {
    final isActive = provider.isLockEnabled;
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: isActive
                ? [const Color(0xFF1A3A5C), const Color(0xFF0D2137)]
                : [const Color(0xFF2A1A1A), const Color(0xFF1A0D0D)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isActive
                ? AppTheme.primaryBlue.withOpacity(0.4)
                : AppTheme.dangerRed.withOpacity(0.3),
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 56,
              height: 56,
              decoration: BoxDecoration(
                color: (isActive ? AppTheme.primaryBlue : AppTheme.dangerRed).withOpacity(0.2),
                shape: BoxShape.circle,
              ),
              child: Icon(
                isActive ? Icons.security_rounded : Icons.lock_open_rounded,
                color: isActive ? AppTheme.primaryBlue : AppTheme.dangerRed,
                size: 28,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    isActive ? 'القفل المزدوج نشط' : 'القفل غير مفعّل',
                    style: const TextStyle(
                      color: AppTheme.pureWhite,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    isActive
                        ? 'هاتفك محمي بنمطين مختلفين'
                        : 'قم بإعداد النمطين لتفعيل الحماية',
                    style: const TextStyle(color: AppTheme.greyText, fontSize: 13),
                  ),
                ],
              ),
            ),
            Switch(
              value: isActive,
              onChanged: (val) async {
                final hasReal = await provider.hasRealPattern();
                final hasDecoy = await provider.hasDecoyPattern();
                if (!hasReal || !hasDecoy) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('يجب إعداد النمطين أولاً'),
                      backgroundColor: AppTheme.dangerRed,
                    ),
                  );
                  return;
                }
                provider.setLockEnabled(val);
              },
              activeColor: AppTheme.primaryBlue,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMainOptions(BuildContext context, AppStateProvider provider) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SectionHeader(
          title: 'إعداد القفل',
          subtitle: 'قم بتكوين النمطين',
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: _LockOptionCard(
                icon: Icons.lock_rounded,
                title: 'القفل الحقيقي',
                subtitle: 'يفتح الهاتف الأصلي',
                color: AppTheme.primaryBlue,
                onTap: () => Navigator.push(context, MaterialPageRoute(
                  builder: (_) => const SetupPatternScreen(isReal: true),
                )),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: _LockOptionCard(
                icon: Icons.layers_rounded,
                title: 'القفل الوهمي',
                subtitle: 'يفتح الواجهة البديلة',
                color: const Color(0xFF7C4DFF),
                onTap: () => Navigator.push(context, MaterialPageRoute(
                  builder: (_) => const SetupPatternScreen(isReal: false),
                )),
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        GlassCard(
          onTap: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => const DecoySetupScreen())),
          child: Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: const Color(0xFF00BCD4).withOpacity(0.15),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: const Icon(Icons.phone_android_rounded,
                    color: Color(0xFF00BCD4), size: 26),
              ),
              const SizedBox(width: 16),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('إعداد الواجهة الوهمية',
                        style: TextStyle(
                            color: AppTheme.pureWhite,
                            fontWeight: FontWeight.bold,
                            fontSize: 15)),
                    SizedBox(height: 3),
                    Text('اختر التطبيقات والمحتوى الذي سيظهر',
                        style: TextStyle(color: AppTheme.greyText, fontSize: 12)),
                  ],
                ),
              ),
              const Icon(Icons.arrow_forward_ios_rounded,
                  color: AppTheme.greyText, size: 16),
            ],
          ),
        ),
        const SizedBox(height: 16),
        // Test lock screen
        GlassCard(
          borderColor: AppTheme.primaryBlue.withOpacity(0.3),
          onTap: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => const LockScreen())),
          child: Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: AppTheme.primaryBlue.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: const Icon(Icons.preview_rounded,
                    color: AppTheme.primaryBlue, size: 26),
              ),
              const SizedBox(width: 16),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('اختبار شاشة القفل',
                        style: TextStyle(
                            color: AppTheme.pureWhite,
                            fontWeight: FontWeight.bold,
                            fontSize: 15)),
                    SizedBox(height: 3),
                    Text('جرّب القفل الحقيقي والوهمي',
                        style: TextStyle(color: AppTheme.greyText, fontSize: 12)),
                  ],
                ),
              ),
              const Icon(Icons.arrow_forward_ios_rounded,
                  color: AppTheme.greyText, size: 16),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildQuickActions(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SectionHeader(title: 'الصفحات والمعلومات'),
        const SizedBox(height: 16),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          childAspectRatio: 2.5,
          children: [
            _InfoTile(icon: Icons.info_rounded, label: 'حول التطبيق',
                onTap: () => Navigator.push(context, MaterialPageRoute(
                    builder: (_) => const AboutScreen()))),
            _InfoTile(icon: Icons.people_rounded, label: 'من نحن',
                onTap: () => Navigator.push(context, MaterialPageRoute(
                    builder: (_) => const WhoWeAreScreen()))),
            _InfoTile(icon: Icons.privacy_tip_rounded, label: 'سياسة الخصوصية',
                onTap: () => Navigator.push(context, MaterialPageRoute(
                    builder: (_) => const PrivacyPolicyScreen()))),
            _InfoTile(icon: Icons.description_rounded, label: 'شروط الاستخدام',
                onTap: () => Navigator.push(context, MaterialPageRoute(
                    builder: (_) => const TermsScreen()))),
            _InfoTile(icon: Icons.help_rounded, label: 'كيف يعمل',
                onTap: () => Navigator.push(context, MaterialPageRoute(
                    builder: (_) => const HowItWorksScreen()))),
            _InfoTile(icon: Icons.person_rounded, label: 'الحساب',
                onTap: () => Navigator.push(context, MaterialPageRoute(
                    builder: (_) => const AuthScreen()))),
          ],
        ),
        const SizedBox(height: 30),
      ],
    );
  }
}

class _LockOptionCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;

  const _LockOptionCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: AppTheme.cardBlack,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: color.withOpacity(0.25)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: color.withOpacity(0.15),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: color, size: 24),
            ),
            const SizedBox(height: 14),
            Text(title,
                style: const TextStyle(
                    color: AppTheme.pureWhite,
                    fontWeight: FontWeight.bold,
                    fontSize: 14)),
            const SizedBox(height: 4),
            Text(subtitle,
                style: const TextStyle(color: AppTheme.greyText, fontSize: 11)),
          ],
        ),
      ),
    );
  }
}

class _InfoTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _InfoTile({required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: AppTheme.cardBlack,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppTheme.dividerColor),
        ),
        child: Row(
          children: [
            Icon(icon, color: AppTheme.primaryBlue, size: 20),
            const SizedBox(width: 8),
            Expanded(
              child: Text(label,
                  style: const TextStyle(
                      color: AppTheme.softWhite, fontSize: 12),
                  overflow: TextOverflow.ellipsis),
            ),
          ],
        ),
      ),
    );
  }
}

// Placeholder screens referenced above
class AuthScreen extends StatelessWidget {
  const AuthScreen({super.key});
  @override
  Widget build(BuildContext context) => const _PlaceholderScreen(title: 'الحساب');
}

class _PlaceholderScreen extends StatelessWidget {
  final String title;
  const _PlaceholderScreen({required this.title});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: const Center(child: Text('قريباً...', style: TextStyle(color: AppTheme.greyText))),
    );
  }
}

// Import in actual file - extracted for space
class SectionHeader extends StatelessWidget {
  final String title;
  final String? subtitle;
  const SectionHeader({super.key, required this.title, this.subtitle});
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: const TextStyle(
          color: AppTheme.pureWhite, fontSize: 18, fontWeight: FontWeight.bold)),
        if (subtitle != null)
          Text(subtitle!, style: const TextStyle(color: AppTheme.greyText, fontSize: 13)),
      ],
    );
  }
}

class GlassCard extends StatelessWidget {
  final Widget child;
  final VoidCallback? onTap;
  final Color? borderColor;
  const GlassCard({super.key, required this.child, this.onTap, this.borderColor});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppTheme.cardBlack,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: borderColor ?? AppTheme.dividerColor),
        ),
        child: child,
      ),
    );
  }
}
