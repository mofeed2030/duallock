// lib/screens/lockscreen/setup_pattern_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../../utils/app_theme.dart';
import '../../services/app_state_provider.dart';

class SetupPatternScreen extends StatefulWidget {
  final bool isReal;
  const SetupPatternScreen({super.key, required this.isReal});

  @override
  State<SetupPatternScreen> createState() => _SetupPatternScreenState();
}

class _SetupPatternScreenState extends State<SetupPatternScreen> {
  final List<int> _pin = [];
  final List<int> _confirmPin = [];
  bool _isConfirming = false;
  bool _hasError = false;
  String _errorMessage = '';

  String get _title => widget.isReal ? 'إنشاء النمط الحقيقي' : 'إنشاء النمط الوهمي';
  String get _subtitle => widget.isReal
      ? 'هذا النمط يفتح هاتفك الحقيقي'
      : 'هذا النمط يفتح الواجهة الوهمية';
  Color get _color => widget.isReal ? AppTheme.primaryBlue : const Color(0xFF7C4DFF);

  List<int> get _activePin => _isConfirming ? _confirmPin : _pin;

  void _onDigitPressed(int digit) {
    if (_activePin.length >= 6) return;
    HapticFeedback.lightImpact();
    setState(() {
      _activePin.add(digit);
      _hasError = false;
    });

    if (_activePin.length == 6) {
      if (!_isConfirming) {
        // First entry complete - ask to confirm
        Future.delayed(const Duration(milliseconds: 300), () {
          if (mounted) setState(() => _isConfirming = true);
        });
      } else {
        // Confirming - check match
        _verifyMatch();
      }
    }
  }

  void _onDelete() {
    if (_activePin.isEmpty) return;
    HapticFeedback.lightImpact();
    setState(() => _activePin.removeLast());
  }

  Future<void> _verifyMatch() async {
    if (_pin.join() == _confirmPin.join()) {
      // Save pattern
      final provider = context.read<AppStateProvider>();
      if (widget.isReal) {
        await provider.saveRealPattern(_pin.join());
      } else {
        await provider.saveDecoyPattern(_pin.join());
      }
      if (!mounted) return;
      HapticFeedback.mediumImpact();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(widget.isReal
              ? 'تم حفظ النمط الحقيقي بنجاح ✓'
              : 'تم حفظ النمط الوهمي بنجاح ✓'),
          backgroundColor: AppTheme.successGreen,
        ),
      );
      Navigator.pop(context);
    } else {
      HapticFeedback.heavyImpact();
      setState(() {
        _hasError = true;
        _errorMessage = 'الرمزان غير متطابقان، حاول مرة أخرى';
        _isConfirming = false;
        _pin.clear();
        _confirmPin.clear();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.primaryBlack,
      appBar: AppBar(
        title: Text(_title),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 40),
            // Icon
            Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                color: _color.withOpacity(0.15),
                shape: BoxShape.circle,
                border: Border.all(color: _color.withOpacity(0.3), width: 2),
              ),
              child: Icon(
                widget.isReal ? Icons.lock_rounded : Icons.layers_rounded,
                color: _color,
                size: 40,
              ),
            ),
            const SizedBox(height: 24),
            Text(
              _isConfirming ? 'تأكيد الرمز' : _title,
              style: const TextStyle(
                  color: AppTheme.pureWhite,
                  fontSize: 22,
                  fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(
              _isConfirming ? 'أعد إدخال الرمز للتأكيد' : _subtitle,
              style: const TextStyle(color: AppTheme.greyText, fontSize: 14),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            // Error
            AnimatedOpacity(
              opacity: _hasError ? 1 : 0,
              duration: const Duration(milliseconds: 300),
              child: Text(
                _errorMessage,
                style: const TextStyle(color: AppTheme.dangerRed, fontSize: 13),
              ),
            ),
            const SizedBox(height: 40),
            // PIN dots
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(6, (i) => AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                margin: const EdgeInsets.symmetric(horizontal: 8),
                width: 14,
                height: 14,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: i < _activePin.length ? _color : Colors.transparent,
                  border: Border.all(
                    color: i < _activePin.length
                        ? _color
                        : AppTheme.greyText.withOpacity(0.4),
                    width: 1.5,
                  ),
                ),
              )),
            ),
            const Spacer(),
            // Keypad
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: Column(
                children: [
                  for (var row in [[1,2,3],[4,5,6],[7,8,9]])
                    Padding(
                      padding: const EdgeInsets.only(bottom: 16),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: row.map((d) => _buildKey(d)).toList(),
                      ),
                    ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      const SizedBox(width: 72),
                      _buildKey(0),
                      GestureDetector(
                        onTap: _onDelete,
                        child: const SizedBox(
                          width: 72,
                          height: 72,
                          child: Icon(Icons.backspace_rounded,
                              color: AppTheme.greyText, size: 24),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  Widget _buildKey(int digit) {
    return GestureDetector(
      onTap: () => _onDigitPressed(digit),
      child: Container(
        width: 72,
        height: 72,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: AppTheme.cardBlack,
          border: Border.all(color: AppTheme.dividerColor),
        ),
        child: Center(
          child: Text('$digit',
              style: const TextStyle(
                  color: AppTheme.pureWhite,
                  fontSize: 26,
                  fontWeight: FontWeight.w300)),
        ),
      ),
    );
  }
}
