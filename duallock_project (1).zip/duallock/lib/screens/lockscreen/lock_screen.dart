// lib/screens/lockscreen/lock_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../../utils/app_theme.dart';
import '../../services/app_state_provider.dart';
import '../../services/security_service.dart';
import '../decoy/decoy_home_screen.dart';

class LockScreen extends StatefulWidget {
  const LockScreen({super.key});

  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen>
    with SingleTickerProviderStateMixin {
  final List<int> _enteredPin = [];
  int _attempts = 0;
  bool _showError = false;
  bool _isProcessing = false;
  late AnimationController _shakeController;
  late Animation<double> _shakeAnim;

  @override
  void initState() {
    super.initState();
    _shakeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _shakeAnim = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _shakeController, curve: Curves.elasticIn),
    );
    // Make status bar invisible for immersive lock screen
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersive);
  }

  @override
  void dispose() {
    _shakeController.dispose();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  void _onDigitPressed(int digit) {
    if (_enteredPin.length >= 6 || _isProcessing) return;
    HapticFeedback.lightImpact();
    setState(() {
      _enteredPin.add(digit);
      _showError = false;
    });
    if (_enteredPin.length == 6) {
      _verifyPin();
    }
  }

  void _onDelete() {
    if (_enteredPin.isEmpty) return;
    HapticFeedback.lightImpact();
    setState(() => _enteredPin.removeLast());
  }

  Future<void> _verifyPin() async {
    setState(() => _isProcessing = true);
    await Future.delayed(const Duration(milliseconds: 300));

    final pin = _enteredPin.join();
    final provider = context.read<AppStateProvider>();
    final result = await provider.verifyPattern(pin);

    if (!mounted) return;

    if (result == PatternType.real) {
      HapticFeedback.mediumImpact();
      // Exit to real home
      Navigator.of(context).popUntil((route) => route.isFirst);
    } else if (result == PatternType.decoy) {
      HapticFeedback.mediumImpact();
      // Open decoy interface
      await provider.setDecoyMode(true);
      Navigator.pushReplacement(context,
          MaterialPageRoute(builder: (_) => const DecoyHomeScreen()));
    } else {
      HapticFeedback.heavyImpact();
      _attempts++;
      _shakeController.forward(from: 0);
      setState(() {
        _showError = true;
        _enteredPin.clear();
        _isProcessing = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => false, // Prevent back button
      child: Scaffold(
        backgroundColor: AppTheme.primaryBlack,
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0xFF0A0A1A), Color(0xFF050510)],
            ),
          ),
          child: SafeArea(
            child: Column(
              children: [
                const SizedBox(height: 40),
                // Time display
                _buildTimeDisplay(),
                const SizedBox(height: 40),
                // Lock icon
                const Icon(Icons.lock_rounded, color: AppTheme.primaryBlue, size: 40),
                const SizedBox(height: 16),
                const Text(
                  'أدخل الرمز',
                  style: TextStyle(
                    color: AppTheme.pureWhite,
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                // Error message
                AnimatedOpacity(
                  opacity: _showError ? 1 : 0,
                  duration: const Duration(milliseconds: 300),
                  child: Text(
                    _attempts >= 5
                        ? 'تحذير: $_attempts محاولات فاشلة'
                        : 'رمز غير صحيح، حاول مرة أخرى',
                    style: TextStyle(
                      color: _attempts >= 5 ? AppTheme.dangerRed : AppTheme.greyText,
                      fontSize: 14,
                    ),
                  ),
                ),
                const SizedBox(height: 40),
                // PIN dots
                AnimatedBuilder(
                  animation: _shakeAnim,
                  builder: (context, child) {
                    return Transform.translate(
                      offset: Offset(
                          10 * Math.sin(_shakeAnim.value * 6 * 3.14), 0),
                      child: child,
                    );
                  },
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(6, (i) => _PinDot(
                      filled: i < _enteredPin.length,
                      hasError: _showError,
                    )),
                  ),
                ),
                const Spacer(),
                // Keypad
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 40),
                  child: _buildKeypad(),
                ),
                const SizedBox(height: 40),
                // Panic button (if enabled)
                _buildPanicButton(),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTimeDisplay() {
    return Column(
      children: [
        Text(
          _getFormattedTime(),
          style: const TextStyle(
            color: AppTheme.pureWhite,
            fontSize: 64,
            fontWeight: FontWeight.w200,
            letterSpacing: -2,
          ),
        ),
        Text(
          _getFormattedDate(),
          style: const TextStyle(color: AppTheme.greyText, fontSize: 16),
        ),
      ],
    );
  }

  String _getFormattedTime() {
    final now = DateTime.now();
    return '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';
  }

  String _getFormattedDate() {
    final days = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
    final months = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
                    'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
    final now = DateTime.now();
    return '${days[now.weekday % 7]}، ${now.day} ${months[now.month - 1]}';
  }

  Widget _buildKeypad() {
    return Column(
      children: [
        for (var row in [[1,2,3],[4,5,6],[7,8,9]])
          Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: row.map((d) => _KeypadButton(
                digit: d,
                onTap: () => _onDigitPressed(d),
              )).toList(),
            ),
          ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            const SizedBox(width: 72),
            _KeypadButton(digit: 0, onTap: () => _onDigitPressed(0)),
            _DeleteButton(onTap: _onDelete),
          ],
        ),
      ],
    );
  }

  Widget _buildPanicButton() {
    return Consumer<AppStateProvider>(
      builder: (_, provider, __) {
        if (!provider.settings.showPanicButton) return const SizedBox();
        return TextButton.icon(
          onPressed: _triggerPanic,
          icon: const Icon(Icons.warning_rounded, color: AppTheme.dangerRed, size: 16),
          label: const Text('طوارئ', style: TextStyle(color: AppTheme.dangerRed, fontSize: 13)),
        );
      },
    );
  }

  void _triggerPanic() {
    // Close sensitive apps immediately
    HapticFeedback.heavyImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('تم تفعيل وضع الطوارئ'),
        backgroundColor: AppTheme.dangerRed,
      ),
    );
  }
}

class _PinDot extends StatelessWidget {
  final bool filled;
  final bool hasError;
  const _PinDot({required this.filled, this.hasError = false});

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      margin: const EdgeInsets.symmetric(horizontal: 8),
      width: 14,
      height: 14,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: filled
            ? (hasError ? AppTheme.dangerRed : AppTheme.primaryBlue)
            : Colors.transparent,
        border: Border.all(
          color: filled
              ? (hasError ? AppTheme.dangerRed : AppTheme.primaryBlue)
              : AppTheme.greyText.withOpacity(0.5),
          width: 1.5,
        ),
      ),
    );
  }
}

class _KeypadButton extends StatelessWidget {
  final int digit;
  final VoidCallback onTap;
  const _KeypadButton({required this.digit, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 72,
        height: 72,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: AppTheme.cardBlack,
          border: Border.all(color: AppTheme.dividerColor),
        ),
        child: Center(
          child: Text(
            '$digit',
            style: const TextStyle(
              color: AppTheme.pureWhite,
              fontSize: 26,
              fontWeight: FontWeight.w300,
            ),
          ),
        ),
      ),
    );
  }
}

class _DeleteButton extends StatelessWidget {
  final VoidCallback onTap;
  const _DeleteButton({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: const SizedBox(
        width: 72,
        height: 72,
        child: Icon(Icons.backspace_rounded, color: AppTheme.greyText, size: 24),
      ),
    );
  }
}

// Workaround for math
class Math {
  static double sin(double x) {
    // Simple sine approximation
    return (x % (2 * 3.14159) < 3.14159) ? 1.0 : -1.0;
  }
}
