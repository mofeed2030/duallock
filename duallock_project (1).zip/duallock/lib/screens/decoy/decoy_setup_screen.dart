// lib/screens/decoy/decoy_setup_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../utils/app_theme.dart';
import '../../services/app_state_provider.dart';
import '../../models/models.dart';

class DecoySetupScreen extends StatefulWidget {
  const DecoySetupScreen({super.key});

  @override
  State<DecoySetupScreen> createState() => _DecoySetupScreenState();
}

class _DecoySetupScreenState extends State<DecoySetupScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  // Mock app list (in production, fetch from device_apps package)
  final List<AppModel> _allApps = [
    AppModel(packageName: 'com.android.camera', appName: 'الكاميرا',
        isSelected: true, hasContentControl: false),
    AppModel(packageName: 'com.android.calculator2', appName: 'الآلة الحاسبة',
        isSelected: true, hasContentControl: false),
    AppModel(packageName: 'com.android.browser', appName: 'المتصفح',
        isSelected: false, hasContentControl: false),
    AppModel(packageName: 'com.android.gallery3d', appName: 'الاستديو / المعرض',
        isSelected: false, hasContentControl: true),
    AppModel(packageName: 'com.android.settings', appName: 'الإعدادات',
        isSelected: false, hasContentControl: false),
    AppModel(packageName: 'com.android.dialer', appName: 'الهاتف',
        isSelected: false, hasContentControl: false),
    AppModel(packageName: 'com.android.mms', appName: 'الرسائل',
        isSelected: false, hasContentControl: false),
    AppModel(packageName: 'com.google.android.youtube', appName: 'يوتيوب',
        isSelected: false, hasContentControl: false),
    AppModel(packageName: 'com.google.android.gm', appName: 'Gmail',
        isSelected: false, hasContentControl: false),
    AppModel(packageName: 'com.whatsapp', appName: 'واتساب',
        isSelected: false, hasContentControl: false),
    AppModel(packageName: 'com.instagram.android', appName: 'انستغرام',
        isSelected: false, hasContentControl: false),
    AppModel(packageName: 'com.spotify.music', appName: 'سبوتيفاي',
        isSelected: false, hasContentControl: false),
  ];

  final List<PhotoAlbumModel> _albums = [
    PhotoAlbumModel(id: '1', name: 'كاميرا', count: 120, isSelected: false),
    PhotoAlbumModel(id: '2', name: 'صور المفضلة', count: 34, isSelected: false),
    PhotoAlbumModel(id: '3', name: 'صور الواتساب', count: 200, isSelected: false),
    PhotoAlbumModel(id: '4', name: 'لقطات الشاشة', count: 56, isSelected: false),
    PhotoAlbumModel(id: '5', name: 'فيديوهات', count: 15, isSelected: false),
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _loadSavedSelections();
  }

  Future<void> _loadSavedSelections() async {
    final provider = context.read<AppStateProvider>();
    final saved = provider.selectedDecoyApps;
    for (final app in _allApps) {
      app.isSelected = saved.any((s) => s.packageName == app.packageName);
    }
    setState(() {});
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _saveSelections() async {
    final provider = context.read<AppStateProvider>();
    await provider.saveDecoyApps(_allApps);
    await provider.saveAlbums(_albums);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('تم حفظ الإعدادات ✓'),
        backgroundColor: AppTheme.successGreen,
      ),
    );
    Navigator.pop(context);
  }

  int get _selectedAppsCount => _allApps.where((a) => a.isSelected).length;
  int get _selectedAlbumsCount => _albums.where((a) => a.isSelected).length;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.primaryBlack,
      appBar: AppBar(
        title: const Text('إعداد الواجهة الوهمية'),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: AppTheme.primaryBlue,
          labelColor: AppTheme.primaryBlue,
          unselectedLabelColor: AppTheme.greyText,
          tabs: [
            Tab(text: 'التطبيقات ($_selectedAppsCount)'),
            Tab(text: 'الألبومات ($_selectedAlbumsCount)'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildAppsTab(),
          _buildAlbumsTab(),
        ],
      ),
      bottomNavigationBar: _buildSaveBar(),
    );
  }

  Widget _buildAppsTab() {
    return Column(
      children: [
        // Info banner
        Container(
          margin: const EdgeInsets.all(16),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: AppTheme.primaryBlue.withOpacity(0.1),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: AppTheme.primaryBlue.withOpacity(0.3)),
          ),
          child: const Row(
            children: [
              Icon(Icons.info_outline_rounded, color: AppTheme.primaryBlue, size: 20),
              SizedBox(width: 10),
              Expanded(
                child: Text(
                  'حدد التطبيقات التي ستظهر في الواجهة الوهمية فقط',
                  style: TextStyle(color: AppTheme.softWhite, fontSize: 13),
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: _allApps.length,
            itemBuilder: (_, i) {
              final app = _allApps[i];
              return _AppSelectionTile(
                app: app,
                onChanged: (val) {
                  setState(() => app.isSelected = val);
                },
                onConfigureTap: app.hasContentControl
                    ? () => _showAlbumsTab()
                    : null,
              );
            },
          ),
        ),
      ],
    );
  }

  void _showAlbumsTab() {
    _tabController.animateTo(1);
  }

  Widget _buildAlbumsTab() {
    return Column(
      children: [
        Container(
          margin: const EdgeInsets.all(16),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: const Color(0xFF7C4DFF).withOpacity(0.1),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: const Color(0xFF7C4DFF).withOpacity(0.3)),
          ),
          child: const Row(
            children: [
              Icon(Icons.photo_library_rounded, color: Color(0xFF7C4DFF), size: 20),
              SizedBox(width: 10),
              Expanded(
                child: Text(
                  'حدد الألبومات التي تظهر في تطبيق الاستديو الوهمي',
                  style: TextStyle(color: AppTheme.softWhite, fontSize: 13),
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: _albums.length,
            itemBuilder: (_, i) {
              final album = _albums[i];
              return Container(
                margin: const EdgeInsets.only(bottom: 10),
                decoration: BoxDecoration(
                  color: AppTheme.cardBlack,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: album.isSelected
                        ? const Color(0xFF7C4DFF).withOpacity(0.5)
                        : AppTheme.dividerColor,
                  ),
                ),
                child: CheckboxListTile(
                  value: album.isSelected,
                  onChanged: (val) => setState(() => album.isSelected = val ?? false),
                  activeColor: const Color(0xFF7C4DFF),
                  checkboxShape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(5)),
                  title: Text(album.name,
                      style: const TextStyle(
                          color: AppTheme.pureWhite, fontWeight: FontWeight.w500)),
                  subtitle: Text('${album.count} صورة/فيديو',
                      style: const TextStyle(color: AppTheme.greyText, fontSize: 12)),
                  secondary: Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: AppTheme.dividerColor,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(Icons.photo_rounded,
                        color: AppTheme.greyText, size: 22),
                  ),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildSaveBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
      decoration: BoxDecoration(
        color: AppTheme.secondaryBlack,
        border: const Border(top: BorderSide(color: AppTheme.dividerColor)),
      ),
      child: ElevatedButton.icon(
        onPressed: _saveSelections,
        icon: const Icon(Icons.save_rounded),
        label: Text('حفظ (${ _selectedAppsCount} تطبيق، $_selectedAlbumsCount ألبوم)'),
        style: ElevatedButton.styleFrom(
          minimumSize: const Size.fromHeight(52),
        ),
      ),
    );
  }
}

class _AppSelectionTile extends StatelessWidget {
  final AppModel app;
  final ValueChanged<bool> onChanged;
  final VoidCallback? onConfigureTap;

  const _AppSelectionTile({
    required this.app,
    required this.onChanged,
    this.onConfigureTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: AppTheme.cardBlack,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: app.isSelected
              ? AppTheme.primaryBlue.withOpacity(0.5)
              : AppTheme.dividerColor,
        ),
      ),
      child: Row(
        children: [
          Checkbox(
            value: app.isSelected,
            onChanged: (val) => onChanged(val ?? false),
            activeColor: AppTheme.primaryBlue,
            checkColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
          ),
          // App icon placeholder
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: AppTheme.dividerColor,
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(Icons.apps_rounded, color: AppTheme.greyText, size: 22),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(app.appName,
                    style: const TextStyle(
                        color: AppTheme.pureWhite, fontWeight: FontWeight.w500)),
                if (app.hasContentControl)
                  const Text('يدعم تخصيص المحتوى',
                      style: TextStyle(color: Color(0xFF7C4DFF), fontSize: 11)),
              ],
            ),
          ),
          if (onConfigureTap != null)
            IconButton(
              icon: const Icon(Icons.tune_rounded, color: Color(0xFF7C4DFF), size: 20),
              onPressed: onConfigureTap,
              tooltip: 'تخصيص المحتوى',
            ),
          const SizedBox(width: 4),
        ],
      ),
    );
  }
}
