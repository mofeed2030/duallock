// lib/screens/decoy/decoy_gallery_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../utils/app_theme.dart';
import '../../services/app_state_provider.dart';
import '../../models/models.dart';

class DecoyGalleryScreen extends StatefulWidget {
  const DecoyGalleryScreen({super.key});

  @override
  State<DecoyGalleryScreen> createState() => _DecoyGalleryScreenState();
}

class _DecoyGalleryScreenState extends State<DecoyGalleryScreen> {
  int _selectedAlbumIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Consumer<AppStateProvider>(
      builder: (context, provider, _) {
        final albums = provider.selectedAlbums;

        return Scaffold(
          backgroundColor: AppTheme.primaryBlack,
          appBar: AppBar(
            title: const Text('الاستديو'),
            backgroundColor: AppTheme.primaryBlack,
          ),
          body: albums.isEmpty
              ? _buildEmpty()
              : Column(
                  children: [
                    // Album selector
                    _buildAlbumSelector(albums),
                    // Photos grid
                    Expanded(child: _buildPhotosGrid(albums)),
                  ],
                ),
        );
      },
    );
  }

  Widget _buildEmpty() {
    return const Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.photo_library_outlined, color: AppTheme.greyText, size: 60),
          SizedBox(height: 16),
          Text('لا توجد ألبومات', style: TextStyle(color: AppTheme.greyText)),
        ],
      ),
    );
  }

  Widget _buildAlbumSelector(List<PhotoAlbumModel> albums) {
    return SizedBox(
      height: 50,
      child: ListView.builder(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        scrollDirection: Axis.horizontal,
        itemCount: albums.length,
        itemBuilder: (_, i) {
          final isSelected = _selectedAlbumIndex == i;
          return GestureDetector(
            onTap: () => setState(() => _selectedAlbumIndex = i),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              margin: const EdgeInsets.only(right: 8),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
              decoration: BoxDecoration(
                color: isSelected ? AppTheme.primaryBlue : AppTheme.cardBlack,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                albums[i].name,
                style: TextStyle(
                  color: isSelected ? Colors.white : AppTheme.greyText,
                  fontSize: 13,
                  fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildPhotosGrid(List<PhotoAlbumModel> albums) {
    final album = albums[_selectedAlbumIndex];
    // In production, load actual photos from the selected album
    // For now show placeholder grid
    return GridView.builder(
      padding: const EdgeInsets.all(2),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        mainAxisSpacing: 2,
        crossAxisSpacing: 2,
      ),
      itemCount: album.count.clamp(0, 50),
      itemBuilder: (_, i) => _PhotoTile(index: i),
    );
  }
}

class _PhotoTile extends StatelessWidget {
  final int index;
  const _PhotoTile({required this.index});

  @override
  Widget build(BuildContext context) {
    // Gradient placeholder simulating a photo
    final colors = [
      [const Color(0xFF1A3A5C), const Color(0xFF0D2137)],
      [const Color(0xFF2D1B69), const Color(0xFF1A0D40)],
      [const Color(0xFF1B4332), const Color(0xFF0D2118)],
      [const Color(0xFF3D1A1A), const Color(0xFF1A0A0A)],
    ];
    final colorPair = colors[index % colors.length];

    return GestureDetector(
      onTap: () => _viewPhoto(context),
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: colorPair,
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Center(
          child: Icon(
            Icons.image_rounded,
            color: Colors.white.withOpacity(0.2),
            size: 28,
          ),
        ),
      ),
    );
  }

  void _viewPhoto(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => _PhotoViewScreen(index: index),
      ),
    );
  }
}

class _PhotoViewScreen extends StatelessWidget {
  final int index;
  const _PhotoViewScreen({required this.index});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Center(
        child: Container(
          width: double.infinity,
          height: double.infinity,
          color: const Color(0xFF1A1A2E),
          child: const Icon(Icons.image_rounded, color: Colors.white24, size: 80),
        ),
      ),
    );
  }
}
