// lib/screens/decoy/decoy_home_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../../utils/app_theme.dart';
import '../../services/app_state_provider.dart';
import '../../models/models.dart';

class DecoyHomeScreen extends StatefulWidget {
  const DecoyHomeScreen({super.key});

  @override
  State<DecoyHomeScreen> createState() => _DecoyHomeScreenState();
}

class _DecoyHomeScreenState extends State<DecoyHomeScreen> {
  int _currentPage = 0;
  final PageController _pageController = PageController();

  @override
  void initState() {
    super.initState();
    // Immersive mode to look like a real home screen
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<AppStateProvider>(
      builder: (context, provider, _) {
        final apps = provider.selectedDecoyApps;

        return WillPopScope(
          onWillPop: () async {
            // Pressing back exits decoy mode
            _exitDecoyMode(context, provider);
            return false;
          },
          child: Scaffold(
            backgroundColor: Colors.transparent,
            body: Stack(
              children: [
                // Wallpaper background
                _buildWallpaper(),
                // Overlay
                Container(color: Colors.black.withOpacity(0.3)),
                // Content
                SafeArea(
                  child: Column(
                    children: [
                      // Status bar
                      _buildFakeStatusBar(),
                      // App grid pages
                      Expanded(
                        child: PageView(
                          controller: _pageController,
                          onPageChanged: (i) => setState(() => _currentPage = i),
                          children: [
                            _buildAppsGrid(apps),
                          ],
                        ),
                      ),
                      // Page indicator
                      if (apps.length > 8)
                        _buildPageIndicator(),
                      // Dock
                      _buildDock(apps),
                      const SizedBox(height: 8),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildWallpaper() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF0D1B2A),
            Color(0xFF1B263B),
            Color(0xFF415A77),
          ],
        ),
      ),
    );
  }

  Widget _buildFakeStatusBar() {
    final now = DateTime.now();
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          Text(
            '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}',
            style: const TextStyle(
                color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
          ),
          const Spacer(),
          const Icon(Icons.signal_cellular_4_bar_rounded, color: Colors.white, size: 16),
          const SizedBox(width: 4),
          const Icon(Icons.wifi_rounded, color: Colors.white, size: 16),
          const SizedBox(width: 4),
          const Icon(Icons.battery_full_rounded, color: Colors.white, size: 16),
        ],
      ),
    );
  }

  Widget _buildAppsGrid(List<AppModel> apps) {
    // Show max 16 apps per page (4x4)
    final gridApps = apps.take(apps.length > 4 ? apps.length - 4 : apps.length).toList();

    return GridView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 4,
        mainAxisSpacing: 20,
        crossAxisSpacing: 10,
        childAspectRatio: 0.8,
      ),
      itemCount: gridApps.length,
      itemBuilder: (_, i) => _AppIcon(app: gridApps[i]),
    );
  }

  Widget _buildPageIndicator() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(2, (i) => Container(
        margin: const EdgeInsets.symmetric(horizontal: 3),
        width: _currentPage == i ? 20 : 6,
        height: 6,
        decoration: BoxDecoration(
          color: _currentPage == i
              ? Colors.white
              : Colors.white.withOpacity(0.4),
          borderRadius: BorderRadius.circular(3),
        ),
      )),
    );
  }

  Widget _buildDock(List<AppModel> apps) {
    // Last 4 apps go to dock
    final dockApps = apps.length > 4
        ? apps.sublist(apps.length - 4)
        : apps.take(4).toList();

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.15),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: Colors.white.withOpacity(0.2)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.2),
            blurRadius: 20,
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: dockApps.map((app) => _AppIcon(app: app, isSmall: true)).toList(),
      ),
    );
  }

  void _exitDecoyMode(BuildContext context, AppStateProvider provider) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppTheme.cardBlack,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('الخروج', style: TextStyle(color: AppTheme.pureWhite)),
        content: const Text(
          'للخروج من الواجهة الوهمية، أدخل النمط الحقيقي',
          style: TextStyle(color: AppTheme.greyText),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء', style: TextStyle(color: AppTheme.greyText)),
          ),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(context);
              await provider.setDecoyMode(false);
              if (!mounted) return;
              Navigator.of(context).popUntil((route) => route.isFirst);
            },
            style: ElevatedButton.styleFrom(backgroundColor: AppTheme.primaryBlue),
            child: const Text('الخروج'),
          ),
        ],
      ),
    );
  }
}

class _AppIcon extends StatelessWidget {
  final AppModel app;
  final bool isSmall;

  const _AppIcon({required this.app, this.isSmall = false});

  @override
  Widget build(BuildContext context) {
    final size = isSmall ? 48.0 : 56.0;
    final fontSize = isSmall ? 10.0 : 11.0;

    // Map package names to icons
    IconData iconData = _getIcon(app.packageName);

    return GestureDetector(
      onTap: () {
        // In production, launch the actual app
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('فتح ${app.appName}'),
            duration: const Duration(seconds: 1),
            backgroundColor: AppTheme.cardBlack,
          ),
        );
      },
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  _getAppColor(app.packageName),
                  _getAppColor(app.packageName).withOpacity(0.7),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(14),
              boxShadow: [
                BoxShadow(
                  color: _getAppColor(app.packageName).withOpacity(0.3),
                  blurRadius: 8,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Icon(iconData, color: Colors.white, size: size * 0.5),
          ),
          const SizedBox(height: 4),
          if (!isSmall)
            Text(
              app.appName,
              style: TextStyle(
                color: Colors.white,
                fontSize: fontSize,
                shadows: const [Shadow(color: Colors.black54, blurRadius: 4)],
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
            ),
        ],
      ),
    );
  }

  IconData _getIcon(String pkg) {
    if (pkg.contains('camera')) return Icons.camera_alt_rounded;
    if (pkg.contains('calculator')) return Icons.calculate_rounded;
    if (pkg.contains('browser') || pkg.contains('chrome')) return Icons.language_rounded;
    if (pkg.contains('gallery') || pkg.contains('photo')) return Icons.photo_library_rounded;
    if (pkg.contains('settings')) return Icons.settings_rounded;
    if (pkg.contains('dialer') || pkg.contains('phone')) return Icons.phone_rounded;
    if (pkg.contains('mms') || pkg.contains('message')) return Icons.message_rounded;
    if (pkg.contains('youtube')) return Icons.play_circle_rounded;
    if (pkg.contains('gmail') || pkg.contains('mail')) return Icons.mail_rounded;
    if (pkg.contains('whatsapp')) return Icons.chat_rounded;
    if (pkg.contains('instagram')) return Icons.photo_camera_rounded;
    if (pkg.contains('spotify')) return Icons.music_note_rounded;
    return Icons.apps_rounded;
  }

  Color _getAppColor(String pkg) {
    if (pkg.contains('camera')) return const Color(0xFF1A73E8);
    if (pkg.contains('calculator')) return const Color(0xFF34A853);
    if (pkg.contains('browser')) return const Color(0xFF4285F4);
    if (pkg.contains('gallery') || pkg.contains('photo')) return const Color(0xFFEA4335);
    if (pkg.contains('settings')) return const Color(0xFF607D8B);
    if (pkg.contains('dialer')) return const Color(0xFF00BFA5);
    if (pkg.contains('mms')) return const Color(0xFF1565C0);
    if (pkg.contains('youtube')) return const Color(0xFFFF0000);
    if (pkg.contains('gmail')) return const Color(0xFFEA4335);
    if (pkg.contains('whatsapp')) return const Color(0xFF25D366);
    if (pkg.contains('instagram')) return const Color(0xFFE91E63);
    if (pkg.contains('spotify')) return const Color(0xFF1DB954);
    return AppTheme.primaryBlue;
  }
}
