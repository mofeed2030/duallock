// lib/database/database_service.dart
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/models.dart';

class DatabaseService {
  static final DatabaseService _instance = DatabaseService._internal();
  factory DatabaseService() => _instance;
  DatabaseService._internal();

  static Database? _db;

  Future<Database> get database async {
    _db ??= await _initDB();
    return _db!;
  }

  Future<Database> _initDB() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'duallock.db');
    return openDatabase(
      path,
      version: 1,
      onCreate: _createDB,
    );
  }

  Future<void> _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE selected_apps (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        packageName TEXT UNIQUE NOT NULL,
        appName TEXT NOT NULL,
        icon TEXT,
        isSelected INTEGER DEFAULT 0,
        hasContentControl INTEGER DEFAULT 0
      )
    ''');

    await db.execute('''
      CREATE TABLE selected_albums (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        albumId TEXT UNIQUE NOT NULL,
        albumName TEXT NOT NULL,
        coverPath TEXT,
        assetCount INTEGER DEFAULT 0,
        isSelected INTEGER DEFAULT 0
      )
    ''');

    await db.execute('''
      CREATE TABLE user_settings (
        id INTEGER PRIMARY KEY,
        isSetupComplete INTEGER DEFAULT 0,
        isLockEnabled INTEGER DEFAULT 0,
        isDecoyEnabled INTEGER DEFAULT 0,
        showPanicButton INTEGER DEFAULT 1,
        hideFromLauncher INTEGER DEFAULT 0,
        decoyWallpaper TEXT DEFAULT 'default',
        decoyTheme TEXT DEFAULT 'dark',
        userEmail TEXT DEFAULT '',
        userId TEXT DEFAULT ''
      )
    ''');

    // Insert default settings
    await db.insert('user_settings', {
      'id': 1,
      'isSetupComplete': 0,
      'isLockEnabled': 0,
      'isDecoyEnabled': 0,
      'showPanicButton': 1,
      'hideFromLauncher': 0,
      'decoyWallpaper': 'default',
      'decoyTheme': 'dark',
      'userEmail': '',
      'userId': '',
    });
  }

  // ─── Apps ───────────────────────────────────────────────
  Future<void> saveSelectedApps(List<AppModel> apps) async {
    final db = await database;
    final batch = db.batch();
    batch.delete('selected_apps');
    for (final app in apps) {
      batch.insert('selected_apps', app.toMap(),
          conflictAlgorithm: ConflictAlgorithm.replace);
    }
    await batch.commit(noResult: true);
  }

  Future<List<AppModel>> getSelectedApps() async {
    final db = await database;
    final maps = await db.query('selected_apps', where: 'isSelected = 1');
    return maps.map((m) => AppModel.fromMap(m)).toList();
  }

  Future<List<AppModel>> getAllSavedApps() async {
    final db = await database;
    final maps = await db.query('selected_apps');
    return maps.map((m) => AppModel.fromMap(m)).toList();
  }

  // ─── Albums ─────────────────────────────────────────────
  Future<void> saveSelectedAlbums(List<PhotoAlbumModel> albums) async {
    final db = await database;
    final batch = db.batch();
    batch.delete('selected_albums');
    for (final album in albums) {
      batch.insert('selected_albums', {
        'albumId': album.id,
        'albumName': album.name,
        'coverPath': album.coverPath,
        'assetCount': album.count,
        'isSelected': album.isSelected ? 1 : 0,
      }, conflictAlgorithm: ConflictAlgorithm.replace);
    }
    await batch.commit(noResult: true);
  }

  Future<List<String>> getSelectedAlbumIds() async {
    final db = await database;
    final maps = await db.query('selected_albums',
        where: 'isSelected = 1', columns: ['albumId']);
    return maps.map((m) => m['albumId'] as String).toList();
  }

  // ─── Settings ───────────────────────────────────────────
  Future<UserSettings> getSettings() async {
    final db = await database;
    final maps = await db.query('user_settings', where: 'id = 1');
    if (maps.isEmpty) return UserSettings();
    return UserSettings.fromMap(maps.first);
  }

  Future<void> updateSettings(UserSettings settings) async {
    final db = await database;
    await db.update('user_settings', settings.toMap(),
        where: 'id = 1');
  }

  Future<void> updateSetting(String key, dynamic value) async {
    final db = await database;
    await db.update('user_settings', {key: value}, where: 'id = 1');
  }

  Future<void> closeDB() async {
    final db = _db;
    if (db != null) {
      await db.close();
      _db = null;
    }
  }
}
