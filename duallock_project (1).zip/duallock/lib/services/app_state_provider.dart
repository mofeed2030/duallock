// lib/services/app_state_provider.dart
import 'package:flutter/foundation.dart';
import '../models/models.dart';
import '../database/database_service.dart';
import '../services/security_service.dart';

class AppStateProvider extends ChangeNotifier {
  final DatabaseService _db = DatabaseService();
  final SecurityService _security = SecurityService();

  UserSettings _settings = UserSettings();
  List<AppModel> _selectedDecoyApps = [];
  List<PhotoAlbumModel> _selectedAlbums = [];
  bool _isLoading = false;
  bool _isInDecoyMode = false;

  UserSettings get settings => _settings;
  List<AppModel> get selectedDecoyApps => _selectedDecoyApps;
  List<PhotoAlbumModel> get selectedAlbums => _selectedAlbums;
  bool get isLoading => _isLoading;
  bool get isInDecoyMode => _isInDecoyMode;
  bool get isSetupComplete => _settings.isSetupComplete;
  bool get isLockEnabled => _settings.isLockEnabled;

  Future<void> initialize() async {
    _isLoading = true;
    notifyListeners();
    _settings = await _db.getSettings();
    _selectedDecoyApps = await _db.getSelectedApps();
    _isLoading = false;
    notifyListeners();
  }

  Future<void> setDecoyMode(bool value) async {
    _isInDecoyMode = value;
    notifyListeners();
  }

  Future<void> saveDecoyApps(List<AppModel> apps) async {
    await _db.saveSelectedApps(apps);
    _selectedDecoyApps = apps.where((a) => a.isSelected).toList();
    notifyListeners();
  }

  Future<void> saveAlbums(List<PhotoAlbumModel> albums) async {
    await _db.saveSelectedAlbums(albums);
    _selectedAlbums = albums.where((a) => a.isSelected).toList();
    notifyListeners();
  }

  Future<void> updateSettings(UserSettings settings) async {
    await _db.updateSettings(settings);
    _settings = settings;
    notifyListeners();
  }

  Future<void> setSetupComplete(bool value) async {
    _settings.isSetupComplete = value;
    await _db.updateSetting('isSetupComplete', value ? 1 : 0);
    notifyListeners();
  }

  Future<void> setLockEnabled(bool value) async {
    _settings.isLockEnabled = value;
    await _db.updateSetting('isLockEnabled', value ? 1 : 0);
    notifyListeners();
  }

  Future<PatternType> verifyPattern(String pattern) async {
    return await _security.checkPattern(pattern);
  }

  Future<bool> hasRealPattern() async => await _security.hasRealPattern();
  Future<bool> hasDecoyPattern() async => await _security.hasDecoyPattern();

  Future<void> saveRealPattern(String pattern) async {
    await _security.saveRealPattern(pattern);
  }

  Future<void> saveDecoyPattern(String pattern) async {
    await _security.saveDecoyPattern(pattern);
  }
}
