// lib/services/system_service.dart
import 'package:flutter/services.dart';

class SystemService {
  static final SystemService _instance = SystemService._internal();
  factory SystemService() => _instance;
  SystemService._internal();

  static const MethodChannel _channel = MethodChannel('com.duallock.app/system');

  // ─── Permissions ────────────────────────────────────────────────────────────

  Future<bool> canDrawOverApps() async {
    try {
      return await _channel.invokeMethod<bool>('canDrawOverApps') ?? false;
    } on PlatformException {
      return false;
    }
  }

  Future<bool> requestDrawOverApps() async {
    try {
      return await _channel.invokeMethod<bool>('requestDrawOverApps') ?? false;
    } on PlatformException {
      return false;
    }
  }

  Future<bool> hasUsageStats() async {
    try {
      return await _channel.invokeMethod<bool>('hasUsageStats') ?? false;
    } on PlatformException {
      return false;
    }
  }

  Future<void> requestUsageStats() async {
    try {
      await _channel.invokeMethod('requestUsageStats');
    } on PlatformException {
      // ignore
    }
  }

  Future<bool> isDeviceAdmin() async {
    try {
      return await _channel.invokeMethod<bool>('isDeviceAdmin') ?? false;
    } on PlatformException {
      return false;
    }
  }

  Future<bool> requestDeviceAdmin() async {
    try {
      return await _channel.invokeMethod<bool>('requestDeviceAdmin') ?? false;
    } on PlatformException {
      return false;
    }
  }

  // ─── Lock Service ────────────────────────────────────────────────────────────

  Future<bool> startLockService() async {
    try {
      return await _channel.invokeMethod<bool>('startLockService') ?? false;
    } on PlatformException {
      return false;
    }
  }

  Future<bool> stopLockService() async {
    try {
      return await _channel.invokeMethod<bool>('stopLockService') ?? false;
    } on PlatformException {
      return false;
    }
  }

  Future<bool> lockScreen() async {
    try {
      return await _channel.invokeMethod<bool>('lockScreen') ?? false;
    } on PlatformException {
      return false;
    }
  }

  // ─── App Visibility ──────────────────────────────────────────────────────────

  Future<void> hideFromLauncher(bool hide) async {
    try {
      await _channel.invokeMethod('hideFromLauncher', {'hide': hide});
    } on PlatformException {
      // ignore
    }
  }

  // ─── Installed Apps ──────────────────────────────────────────────────────────

  Future<List<Map<String, String>>> getInstalledApps() async {
    try {
      final result = await _channel.invokeMethod<List>('getInstalledApps');
      if (result == null) return [];
      return result.map((item) => Map<String, String>.from(item as Map)).toList();
    } on PlatformException {
      return [];
    }
  }

  // ─── Permissions Status Check ────────────────────────────────────────────────

  Future<PermissionsStatus> checkAllPermissions() async {
    final drawOver = await canDrawOverApps();
    final usageStats = await hasUsageStats();
    final deviceAdmin = await isDeviceAdmin();
    return PermissionsStatus(
      drawOverApps: drawOver,
      usageStats: usageStats,
      deviceAdmin: deviceAdmin,
    );
  }
}

class PermissionsStatus {
  final bool drawOverApps;
  final bool usageStats;
  final bool deviceAdmin;

  PermissionsStatus({
    required this.drawOverApps,
    required this.usageStats,
    required this.deviceAdmin,
  });

  bool get allGranted => drawOverApps && usageStats && deviceAdmin;
  int get grantedCount => [drawOverApps, usageStats, deviceAdmin].where((b) => b).length;
}
