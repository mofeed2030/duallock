// lib/services/security_service.dart
import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class SecurityService {
  static final SecurityService _instance = SecurityService._internal();
  factory SecurityService() => _instance;
  SecurityService._internal();

  final FlutterSecureStorage _secureStorage = const FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );

  static const String _salt = 'DualLock_S3cur3_S@lt_2024';

  // Hash a pattern using SHA-256 with salt
  String hashPattern(String pattern) {
    final salted = '$_salt:$pattern:$_salt';
    final bytes = utf8.encode(salted);
    final digest = sha256.convert(bytes);
    return digest.toString();
  }

  // Save real pattern (hashed)
  Future<void> saveRealPattern(String pattern) async {
    final hashed = hashPattern(pattern);
    await _secureStorage.write(key: 'real_pattern', value: hashed);
  }

  // Save decoy pattern (hashed)
  Future<void> saveDecoyPattern(String pattern) async {
    final hashed = hashPattern(pattern);
    await _secureStorage.write(key: 'decoy_pattern', value: hashed);
  }

  // Verify real pattern
  Future<bool> verifyRealPattern(String pattern) async {
    final stored = await _secureStorage.read(key: 'real_pattern');
    if (stored == null) return false;
    return stored == hashPattern(pattern);
  }

  // Verify decoy pattern
  Future<bool> verifyDecoyPattern(String pattern) async {
    final stored = await _secureStorage.read(key: 'decoy_pattern');
    if (stored == null) return false;
    return stored == hashPattern(pattern);
  }

  // Check what pattern type was entered
  Future<PatternType> checkPattern(String pattern) async {
    final isReal = await verifyRealPattern(pattern);
    if (isReal) return PatternType.real;
    final isDecoy = await verifyDecoyPattern(pattern);
    if (isDecoy) return PatternType.decoy;
    return PatternType.invalid;
  }

  // Check if patterns are set
  Future<bool> hasRealPattern() async {
    final stored = await _secureStorage.read(key: 'real_pattern');
    return stored != null && stored.isNotEmpty;
  }

  Future<bool> hasDecoyPattern() async {
    final stored = await _secureStorage.read(key: 'decoy_pattern');
    return stored != null && stored.isNotEmpty;
  }

  // Clear all security data
  Future<void> clearAll() async {
    await _secureStorage.deleteAll();
  }

  // Encrypt arbitrary data
  String encryptData(String data) {
    final bytes = utf8.encode(data + _salt);
    return base64.encode(bytes);
  }

  // Decrypt data
  String decryptData(String encrypted) {
    final bytes = base64.decode(encrypted);
    final decoded = utf8.decode(bytes);
    return decoded.replaceAll(_salt, '');
  }
}

enum PatternType { real, decoy, invalid }
