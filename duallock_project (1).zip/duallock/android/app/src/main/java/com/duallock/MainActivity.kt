// android/app/src/main/java/com/duallock/MainActivity.kt
package com.duallock.app

import android.app.ActivityManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {

    private val CHANNEL = "com.duallock.app/system"
    private lateinit var devicePolicyManager: DevicePolicyManager
    private lateinit var adminComponent: ComponentName

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        devicePolicyManager = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        adminComponent = ComponentName(this, DeviceAdminReceiver::class.java)
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "requestDrawOverApps" -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        if (!Settings.canDrawOverlays(this)) {
                            val intent = Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:$packageName")
                            )
                            startActivity(intent)
                            result.success(false)
                        } else {
                            result.success(true)
                        }
                    } else {
                        result.success(true)
                    }
                }

                "canDrawOverApps" -> {
                    result.success(
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                            Settings.canDrawOverlays(this)
                        else true
                    )
                }

                "requestUsageStats" -> {
                    val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
                    startActivity(intent)
                    result.success(null)
                }

                "hasUsageStats" -> {
                    result.success(hasUsageStatsPermission())
                }

                "requestDeviceAdmin" -> {
                    if (!devicePolicyManager.isAdminActive(adminComponent)) {
                        val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent)
                            putExtra(
                                DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                                "مطلوب لحماية التطبيق من الحذف القسري"
                            )
                        }
                        startActivityForResult(intent, 1)
                        result.success(false)
                    } else {
                        result.success(true)
                    }
                }

                "isDeviceAdmin" -> {
                    result.success(devicePolicyManager.isAdminActive(adminComponent))
                }

                "lockScreen" -> {
                    if (devicePolicyManager.isAdminActive(adminComponent)) {
                        devicePolicyManager.lockNow()
                        result.success(true)
                    } else {
                        result.success(false)
                    }
                }

                "startLockService" -> {
                    val serviceIntent = Intent(this, LockScreenService::class.java)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        startForegroundService(serviceIntent)
                    } else {
                        startService(serviceIntent)
                    }
                    result.success(true)
                }

                "stopLockService" -> {
                    stopService(Intent(this, LockScreenService::class.java))
                    result.success(true)
                }

                "hideFromLauncher" -> {
                    val hide = call.argument<Boolean>("hide") ?: false
                    setLauncherVisibility(hide)
                    result.success(true)
                }

                "getInstalledApps" -> {
                    val pm = packageManager
                    val intent = Intent(Intent.ACTION_MAIN).apply {
                        addCategory(Intent.CATEGORY_LAUNCHER)
                    }
                    val apps = pm.queryIntentActivities(intent, 0).map { info ->
                        mapOf(
                            "packageName" to info.activityInfo.packageName,
                            "appName" to info.loadLabel(pm).toString()
                        )
                    }
                    result.success(apps)
                }

                else -> result.notImplemented()
            }
        }
    }

    private fun hasUsageStatsPermission(): Boolean {
        return try {
            val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val tasks = am.getRunningTasks(1)
            tasks.isNotEmpty()
        } catch (e: Exception) {
            false
        }
    }

    private fun setLauncherVisibility(hide: Boolean) {
        val pm = packageManager
        val component = ComponentName(this, MainActivity::class.java)
        pm.setComponentEnabledSetting(
            component,
            if (hide) android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_DISABLED
            else android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
            android.content.pm.PackageManager.DONT_KILL_APP
        )
    }
}
