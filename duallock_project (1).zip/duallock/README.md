# DualLock - تطبيق القفل المزدوج الذكي

## 📱 وصف التطبيق
DualLock هو تطبيق قفل شاشة ذكي يوفر حماية مزدوجة لهاتفك من خلال:
- **النمط الحقيقي**: يفتح الهاتف بالكامل مع جميع تطبيقاته
- **النمط الوهمي**: يفتح واجهة بديلة مع محتوى محدود تختاره أنت

---

## 🏗️ هيكل المشروع

```
duallock/
├── lib/
│   ├── main.dart                          # نقطة الدخول
│   ├── utils/
│   │   └── app_theme.dart                # الثيم والألوان والثوابت
│   ├── models/
│   │   └── models.dart                   # نماذج البيانات (App, Album, Settings)
│   ├── database/
│   │   └── database_service.dart         # قاعدة بيانات SQLite
│   ├── services/
│   │   ├── security_service.dart         # تشفير الأنماط (SHA-256)
│   │   ├── system_service.dart           # جسر Flutter-Android
│   │   └── app_state_provider.dart       # إدارة الحالة (Provider)
│   ├── screens/
│   │   ├── splash_screen.dart            # شاشة البداية
│   │   ├── onboarding/
│   │   │   ├── onboarding_screen.dart    # شاشات الترحيب
│   │   │   └── permissions_screen.dart  # طلب الأذونات
│   │   ├── home/
│   │   │   └── home_screen.dart         # الشاشة الرئيسية
│   │   ├── lockscreen/
│   │   │   ├── lock_screen.dart         # شاشة القفل
│   │   │   └── setup_pattern_screen.dart # إنشاء النمط
│   │   ├── decoy/
│   │   │   ├── decoy_setup_screen.dart  # إعداد الواجهة الوهمية
│   │   │   ├── decoy_home_screen.dart   # الواجهة الوهمية
│   │   │   └── decoy_gallery_screen.dart # معرض الصور الوهمي
│   │   ├── auth/
│   │   │   └── auth_screen.dart         # تسجيل الدخول
│   │   └── settings/
│   │       ├── settings_screen.dart     # الإعدادات
│   │       └── info_screens.dart        # صفحات المعلومات
│   └── widgets/
│       └── common_widgets.dart          # ويدجت مشتركة
├── android/
│   └── app/src/main/
│       ├── java/com/duallock/
│       │   ├── MainActivity.kt          # Android Entry + MethodChannel
│       │   ├── LockScreenService.kt     # خدمة القفل المستمرة
│       │   └── Receivers.kt            # BootReceiver + DeviceAdminReceiver
│       ├── res/xml/
│       │   └── device_admin.xml         # صلاحيات المدير
│       └── AndroidManifest.xml         # الأذونات والخدمات
└── pubspec.yaml                         # التبعيات
```

---

## 🚀 خطوات تشغيل المشروع

### المتطلبات
- Flutter SDK 3.0+
- Android Studio / VS Code
- Android SDK 26+ (Android 8.0)
- Dart 3.0+

### الخطوات

```bash
# 1. استنساخ المشروع
git clone <repo-url>
cd duallock

# 2. إنشاء مجلدات الأصول
mkdir -p assets/images assets/animations assets/icons assets/fonts

# 3. تنزيل التبعيات
flutter pub get

# 4. تشغيل التطبيق
flutter run
```

---

## 📦 التبعيات الرئيسية

| الحزمة | الغرض |
|--------|-------|
| `provider` | إدارة الحالة |
| `sqflite` | قاعدة البيانات المحلية |
| `flutter_secure_storage` | تخزين آمن مشفر |
| `crypto` | تشفير SHA-256 |
| `local_auth` | بصمة الإصبع / الوجه |
| `permission_handler` | طلب الأذونات |
| `photo_manager` | الوصول للصور والألبومات |
| `google_fonts` | خط Cairo العربي |
| `flutter_animate` | الرسوم المتحركة |

---

## 🔒 آلية الأمان

```
المستخدم يدخل PIN (6 أرقام)
          ↓
  تشفير SHA-256 + Salt
          ↓
  مقارنة مع النمط المخزن
          ↓
   ┌──────┴──────┐
   ↓             ↓
 حقيقي         وهمي
   ↓             ↓
الهاتف       الواجهة
 الأصلي      الوهمية
```

---

## ⚙️ الأذونات المطلوبة

| الإذن | السبب |
|-------|-------|
| `SYSTEM_ALERT_WINDOW` | عرض شاشة القفل فوق التطبيقات |
| `PACKAGE_USAGE_STATS` | مراقبة التطبيقات المفتوحة |
| `BIND_DEVICE_ADMIN` | منع الحذف القسري |
| `FOREGROUND_SERVICE` | استمرار الخدمة في الخلفية |
| `RECEIVE_BOOT_COMPLETED` | التشغيل التلقائي بعد إعادة التشغيل |
| `READ_MEDIA_IMAGES` | عرض الصور في الواجهة الوهمية |

---

## 🎨 الألوان والتصميم

```dart
primaryBlack: #0A0A0F    // الخلفية الرئيسية
cardBlack:    #1A1A24    // بطاقات وعناصر UI
primaryBlue:  #2979FF    // اللون الأساسي
accentBlue:   #448AFF    // اللون الثانوي
pureWhite:    #FFFFFF    // النصوص الرئيسية
greyText:     #9E9E9E    // النصوص الثانوية
```

---

## ⚠️ ملاحظات مهمة

1. **Firebase**: إذا لم تحتاج نظام الحسابات، احذف `firebase_core` و`firebase_auth` من `pubspec.yaml`
2. **Google Fonts**: تأكد من الاتصال بالإنترنت للتحميل الأول، أو أضف الخط محلياً في `assets/fonts/`
3. **الاختبار**: جرّب على جهاز حقيقي (ليس محاكي) لاختبار شاشة القفل بشكل صحيح
4. **Android 12+**: بعض أذونات `SYSTEM_ALERT_WINDOW` قد تحتاج تأكيد إضافي

---

## 🔮 الميزات المستقبلية

- [ ] Pattern Lock (نقاط) بدلاً من PIN
- [ ] قفل بصمة الإصبع
- [ ] تطبيق iOS
- [ ] نسخ احتياطي سحابي تلقائي
- [ ] إحصائيات محاولات الفتح
- [ ] إشعار عند محاولة الفتح الفاشلة

---

*تطبيق DualLock - حماية خصوصيتك بذكاء* 🔐
